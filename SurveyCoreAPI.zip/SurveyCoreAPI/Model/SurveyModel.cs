﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyCoreAPI.Model
{
    public class SurveyModel
    {
        public int SurveyId { get; set; }
        public string Name { get; set; }
        public List<Question> Questions { get; set; }
    }

    public class Question
    {
        public int QuestionId { get; set; }
        public string QuestionName { get; set; }
        public List<string> Option { get; set; }
        public string Answer { get; set; }
    }

    public class SurveyResults
    {
        public string UserName { get; set; }
        public int SurveyId { get; set; }
        public List<SurveyAnswer> SurveyAnswers { get; set; }

    }
    public class SurveyAnswer
    {
        public int QuestionId { get; set; }
        public string Answer { get; set; }
    }
}
  
