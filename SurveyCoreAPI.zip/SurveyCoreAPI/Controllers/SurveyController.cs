﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SurveyCoreAPI.Abstraction;
using SurveyCoreAPI.Model;

namespace SurveyCoreAPI.Controllers
{
    [Route("api/survey")]
    public class SurveyController : Controller
    {
        private readonly ISurvey _iSurvey;

        public SurveyController(ISurvey iSurvey)
        {
            _iSurvey = iSurvey;
        }

        [HttpPost("createsurvey")]
        public IActionResult CreateSurvey([FromBody]SurveyModel surveyModel)
        {
            var response =_iSurvey.CreateSurvey(surveyModel);
            return  Json(response);
        }

        [HttpGet("sendsurveyinvite")]
        public IActionResult SendSurveyInvite(string username)
        {
            var response = _iSurvey.SendSurveyInvite(username);
            return Json(response);
        }

        [HttpGet("pullsurvey")]
        public IActionResult PullSurvey(int surveyId)
        {
            var response = _iSurvey.PullSurvey(surveyId);
            return Json(response);
        }

        [HttpPost("submitsurvey")]
        public IActionResult SubmitSurvey([FromBody]SurveyResults surveyResults )
        {
            var response = _iSurvey.SubmitSurvey(surveyResults);
            return Json(response);
        }

        [HttpGet("surveyresult")]
        public IActionResult SurveyResult(int surveyId)
        {
            var response = _iSurvey.SurveyResult(surveyId);
            return Json(response);
        }
    }
}
