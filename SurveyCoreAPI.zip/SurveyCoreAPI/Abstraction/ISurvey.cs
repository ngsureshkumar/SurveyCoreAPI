﻿using SurveyCoreAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyCoreAPI.Abstraction
{
    public interface ISurvey
    {
        bool CreateSurvey(SurveyModel surveyModel);
        bool SendSurveyInvite(string username);
        SurveyModel PullSurvey(int surveyId);
        bool SubmitSurvey(SurveyResults surveyResults);
        SurveyModel SurveyResult(int surveyId);
        List<SurveyModel> GetSurveys();
    }
}
